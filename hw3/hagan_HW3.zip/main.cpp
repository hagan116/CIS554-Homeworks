/*
  Sam Hagan
  CIS 554 Homework 3
  main.cpp
  
  This file contins a main() function that solely creates a CAI object,
  and calls startTest().
*/
#include "cai.h"

int main(){
  CAI c;
  c.startTest();
  return 0;
}
