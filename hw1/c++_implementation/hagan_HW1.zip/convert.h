/*
  Sam Hagan
  CIS554 Homework 1
  convert.h

  This is the header file for the class Convert
*/

#include <string>

class Convert
{
 public:
  int convert(int,int);
  int recursiveConvert(int,int,int);
};
