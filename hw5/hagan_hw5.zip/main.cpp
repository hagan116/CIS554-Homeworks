/*
 Sam Hagan
 CIS554 Homework 5
 main.cpp
 
 This file contains the main() function, which creates a wordFont object and calls start().
*/
#include "wordFont.h"

int main(){
    
    WordFont w;
    w.start();
    return 0;
}
