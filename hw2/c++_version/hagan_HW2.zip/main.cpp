/*
  Sam Hagan
  CIS 554 Homework 2
  main.cpp

  
*/
#include <iostream>
#include "worker.h"
using namespace std;

// The main() function creates a worker object and calls the calculatePay() function
int main() {
  Worker w;
  w.calculatePay();
  return 0;
}
